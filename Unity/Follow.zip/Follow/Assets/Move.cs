﻿using UnityEngine;
using System.Collections;

public class Move : MonoBehaviour {
	public float speed;

	void start(){
		
	}

	void Update () {

		Vector3 target = Camera.main.ScreenToWorldPoint (Input.mousePosition);
		target.z = transform.position.z;
		transform.position = Vector3.MoveTowards (transform.position, target, speed * Time.deltaTime/transform.localScale.x);
	}
}
