﻿using UnityEngine;
using System.Collections;

public class BulletSpawn : MonoBehaviour {
	public GameObject bullet;
	private float startingtime;
	// Use this for initialization
	void Start () {
		startingtime = Time.time;
	}
	
	// Update is called once per frame
	void Update () {
		if (Time.time > startingtime + 0.3f) {
			Vector3 pos = transform.position;
			Instantiate(bullet,pos,Quaternion.identity);
			startingtime= Time.time;
		}
	}
}
