﻿using UnityEngine;
using System.Collections;

public class ObjectSpawn : MonoBehaviour {
	public GameObject prefab;
	private float startingTime;
	private bool isLeft=true,isRight=false;
	// Use this for initialization
	void Start () {
		startingTime = Time.time;


	}
	
	// Update is called once per frame
	void Update () {
		if (transform.position.x >= 3) {
			isRight = true;
			isLeft = false;
		} else if (transform.position.x <= -3) {
			isRight = false;
			isLeft = true;
		}
		if (Time.time > startingTime + 0.5f && isLeft) {
			transform.Translate(new Vector3(1,0,0));
			Instantiate(prefab,transform.position,Quaternion.identity);
			startingTime = Time.time;
		}
		if (Time.time > startingTime + 0.5f && isRight) {
			transform.Translate(new Vector3(-1,0,0));
			Instantiate(prefab,transform.position,Quaternion.identity);
			startingTime = Time.time;
		}

	}
}
