﻿using UnityEngine;
using System.Collections;

public class MoveShip : MonoBehaviour {
	//public GameObject prefab;

	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		/*if (Input.GetMouseButtonDown(0))
		{
			//Get the mouse position on the screen and send a raycast into the game world from that position.
			Vector2 worldPoint = Camera.main.ScreenToWorldPoint(Input.mousePosition);
			RaycastHit2D hit = Physics2D.Raycast(worldPoint,Vector2.zero);
			
			//If something was hit, the RaycastHit2D.collider will not be null.
			if ( hit.collider != null )
			{

				Destroy(hit.collider.gameObject);
				//Debug.Log( hit.collider.name );
			}*/
		Vector3 temppos = Camera.main.WorldToScreenPoint (transform.position);
		if (temppos.x >= Screen.width) {
			//Vector3 temppos1 = Camera.main.ScreenToWorldPoint (transform.position);
			Debug.Log ("ouch");
		}
		if(Input.GetKey (KeyCode.LeftArrow)){
			transform.Translate(-3.5f*Time.deltaTime,0,0);

		}else if(Input.GetKey(KeyCode.RightArrow)){
			transform.Translate (3.5f*Time.deltaTime,0,0);
		}
		transform.Translate (Input.acceleration.x, 0, 0);
	}
}
