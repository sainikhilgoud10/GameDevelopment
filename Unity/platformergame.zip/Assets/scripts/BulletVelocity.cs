﻿using UnityEngine;
using System.Collections;

public class BulletVelocity : MonoBehaviour {
	public GameObject explosion;
	private TrailRenderer tr;
	// Use this for initialization
	void Start () {
		tr = GetComponent<TrailRenderer> ();

	}
	
	// Update is called once per frame
	void Update () {
		transform.Translate (0, 6f * Time.deltaTime, 0);
		if (transform.position.y > Camera.main.orthographicSize) {
			Destroy(gameObject);
		}
		//explosion.transform.Translate (0, 1f * Time.deltaTime, 0);

	}
	void OnTriggerEnter(Collider collide){
		Instantiate (explosion, transform.position, Quaternion.identity);
		//DestroyImmediate (explosion,true);
		//explosion.SetActive (true);
		//explosion.transform.position = transform.position;
		Destroy (collide.gameObject);
		Destroy (gameObject);
	}
}
