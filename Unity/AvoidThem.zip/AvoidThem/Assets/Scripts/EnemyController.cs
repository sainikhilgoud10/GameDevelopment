﻿using UnityEngine;
using System.Collections;

public class EnemyController : MonoBehaviour {
	private float StartingTime;
	public GameObject prefab;
	private int flag = 1;
	// Use this for initialization
	void Start () {
		StartingTime = Time.time;
	}
	
	// Update is called once per frame
	void Update () {
		if(Time.time > StartingTime + 2 && flag == 1){
			Debug.Log ("cube is left");
			transform.Translate(1,0,0);
			Instantiate(prefab,transform.position,Quaternion.identity);
			flag = 2;
			StartingTime = Time.time;
		}else if(Time.time > StartingTime + 2 && flag == 2){
			Debug.Log("cube is right");
			transform.Translate(-1,0,0);
			Instantiate(prefab,transform.position,Quaternion.identity);
			flag = 1;
			StartingTime = Time.time;
		}
	}
}
