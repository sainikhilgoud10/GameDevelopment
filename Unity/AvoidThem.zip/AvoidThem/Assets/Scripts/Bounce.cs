﻿using UnityEngine;
using System.Collections;

public class Bounce : MonoBehaviour {
	float perc = 1;
	float CurrentLerpTime;
	float LerpTime;
	bool firstinput;
	Vector3 StartPos;
	Vector3 EndPos;
	public bool justjump;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown (KeyCode.LeftArrow) || Input.GetKeyDown (KeyCode.RightArrow) || Input.GetKeyDown (KeyCode.UpArrow)) {
			if(perc == 1){
				LerpTime = 1;
				CurrentLerpTime =0;
				firstinput = true;
				justjump = true;
			}
		}
		StartPos = gameObject.transform.position;
		if (Input.GetKeyDown (KeyCode.RightArrow) && transform.position == EndPos) {
			EndPos = new Vector3(transform.position.x+1,transform.position.y,transform.position.z);
		}
		if (Input.GetKeyDown (KeyCode.LeftArrow) && transform.position == EndPos) {
			EndPos = new Vector3(transform.position.x-1,transform.position.y,transform.position.z);
		}
		if (Input.GetKeyDown (KeyCode.UpArrow) && transform.position == EndPos) {
			EndPos = new Vector3(transform.position.x,transform.position.y,transform.position.z+1);
		}
		if (firstinput == true) {
			CurrentLerpTime += Time.deltaTime * 5;
			perc = CurrentLerpTime/LerpTime;
			gameObject.transform.position = Vector3.Lerp(StartPos,EndPos,perc);
			if(perc>0.8){
				perc = 1;
			}
			if(Mathf.Round(perc) == 1){
				justjump = false;
			}
		}
	}
}
