﻿using UnityEngine;
using System.Collections;

public class AnimationController : MonoBehaviour {
	Animator anim;
	public GameObject theplayer;
	// Use this for initialization
	void Start () {
		anim = gameObject.GetComponent<Animator> ();
	}
	
	// Update is called once per frame
	void Update () {
		Bounce bounceScript = theplayer.GetComponent<Bounce> ();
		if (bounceScript.justjump == true) {
			anim.SetBool ("Jump", true);
		} else {
			anim.SetBool("Jump",false);
		}
	}
}
