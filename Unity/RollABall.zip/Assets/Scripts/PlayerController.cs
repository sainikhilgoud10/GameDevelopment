﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
public class PlayerController : MonoBehaviour {

	public Rigidbody rb;
	public float speed;
	public Transform pickEffect;
	private int count;
	public Text CountText,WinText;
	void Start(){
		rb = GetComponent<Rigidbody>();
		count = 0;
		SetCountText ();
		WinText.text = "";
	}
	void FixedUpdate(){
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");
		Vector3 move = new Vector3 (moveHorizontal,0 , moveVertical);
		rb.AddForce (move * speed);
	}
	void OnTriggerEnter(Collider other){
		if (other.gameObject.CompareTag ("PickUp")) {
			Instantiate(pickEffect,transform.position,transform.rotation);
			other.gameObject.SetActive(false);
			Destroy(other.gameObject);
			count += 1;
			SetCountText();
		}
	}
	void SetCountText(){
		CountText.text = "count:" + count.ToString();
		if (count >= 13) {
			WinText.text = "You Win!";
		}
	}
}
