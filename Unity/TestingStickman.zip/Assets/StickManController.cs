﻿using UnityEngine;
using System.Collections;

public class StickManController : MonoBehaviour {
	private Rigidbody2D rb;
	private SpriteRenderer sr;
	private bool flag = false;
	private Vector3 dir;
	// Use this for initialization
	void Start () {
		rb = this.GetComponent<Rigidbody2D> ();
		sr = this.GetComponent<SpriteRenderer> ();

	}
	private void moveAccordingly(){
		if(flag == true){
			rb.velocity = Vector3.left;
		}
		else{
			rb.velocity = Vector3.right;
		}
	}
	// Update is called once per frame
	void Update () {
		if(Input.GetMouseButtonDown(0) && flag == false){
			
			flag = true;
			sr.flipX = true;
		}else if(Input.GetMouseButtonDown(0) && flag == true){
			flag = false;
			sr.flipX = false;
		}
		moveAccordingly ();
	}
}
