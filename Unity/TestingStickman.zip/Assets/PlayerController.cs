﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

	private Animator animator;
	private Rigidbody2D rb;
	Vector3 dir;
	void Start () {
		animator = this.GetComponent<Animator> ();
		rb = this.GetComponent<Rigidbody2D> ();
	}

	// Update is called once per frame
	void Update () {
		var vertical = Input.GetAxis("Vertical");
		var horizontal = Input.GetAxis("Horizontal");

		rb.velocity = dir;
		if (vertical > 0)
		{
			animator.SetInteger("Direction", 2);
			dir = Vector3.up;

		}
		else if (vertical < 0)
		{
			animator.SetInteger("Direction", 0);
			dir = Vector3.down;
		}
		else if (horizontal > 0)
		{
			animator.SetInteger("Direction", 3);
			dir = Vector3.right;
		}
		else if (horizontal < 0)
		{
			animator.SetInteger("Direction", 1);
			dir = Vector3.left;
		}
	}
}
