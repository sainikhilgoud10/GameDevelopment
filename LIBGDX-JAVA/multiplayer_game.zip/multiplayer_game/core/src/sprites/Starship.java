/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sprites;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Vector2;

/**
 *
 * @author sai
 */
public class Starship extends Sprite {
    Vector2 previousPosition;
    public Starship(Texture texture){
        super(texture);
        previousPosition = new Vector2(getX(),getY());
    }
    
    public boolean hasMoved(){
        if(previousPosition.x != getX() || previousPosition.y!=getY()){
            previousPosition.x = getX();
            previousPosition.y = getY();
            return true;
        }
        return false;
    }
}
