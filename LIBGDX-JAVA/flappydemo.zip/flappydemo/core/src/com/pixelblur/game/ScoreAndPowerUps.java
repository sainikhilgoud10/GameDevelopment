
package com.pixelblur.game;


public class ScoreAndPowerUps {
    
}
