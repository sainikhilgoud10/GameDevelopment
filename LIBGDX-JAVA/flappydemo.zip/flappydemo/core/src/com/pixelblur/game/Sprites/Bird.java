
package com.pixelblur.game.Sprites;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector3;


public class Bird {
    private static int GRAVITY = -15;
    private static int MOVEMENT = 120;
    final private Vector3 position;
    final private Vector3 velocity;
    final private Texture texture;
    final private Rectangle Bounds;
    //final private Ellipse exactBounds;
    final private Animation birdAnimation;
    final public Sound flap;final public Music hit;
    private boolean collision = false;
    private boolean hitplayed = false;
    public Bird(int x,int y){
        position = new Vector3(x,y,0);
        velocity = new Vector3(0,0,0); 
        texture = new Texture("birdanimation.png");
        birdAnimation = new Animation(new TextureRegion(texture),3,0.5f);
        Bounds = new Rectangle(x,y,texture.getWidth()/3,texture.getHeight());
        
        flap = Gdx.audio.newSound(Gdx.files.internal("sfx_wing.ogg"));
        hit = Gdx.audio.newMusic(Gdx.files.internal("sfx_hit.ogg"));
        hit.setLooping(false);
    }
    
    public void update(float dt){
        if(collision == false)
            birdAnimation.update(dt);
        if(position.y>0 && collision==false)
            velocity.add(0, GRAVITY, 0);
        velocity.scl(dt);
        position.add(MOVEMENT*dt,velocity.y,0);
        
        if(position.y<0)
            position.y = 0;
        Bounds.setPosition(position.x,position.y);
        
        velocity.scl(1/dt);
        
        if(collision==true){
            MOVEMENT = 0;
            GRAVITY = 0;
            velocity.y= 0;
            
        }else{
            MOVEMENT = 100;
            GRAVITY = -15;
            
        }
    }
    
    public TextureRegion getBird(){
        return birdAnimation.getFrame();
    }
    
    public Vector3 getPosition(){
        return position;
    }
    
    public void jump(){
        if(collision == false){
            velocity.y = 250;
            flap.play(0.8f);
        }
        
    }
   
    public Rectangle getBounds(){
        return Bounds;
    }
    public void dispose(){
        System.out.println("dispose called");
        texture.dispose();
        flap.dispose();
        hit.dispose();
    }
    public void setCollision(boolean collided){
        collision = collided;
        if(collision==true && hitplayed==false){
            hit.play();
            hitplayed = true;
        }
 
    }

    public boolean getCollision(){
        return collision;
    }
}

