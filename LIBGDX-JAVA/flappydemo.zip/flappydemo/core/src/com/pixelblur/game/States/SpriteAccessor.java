
package com.pixelblur.game.States;

import aurelienribon.tweenengine.TweenAccessor;
import com.badlogic.gdx.graphics.g2d.Sprite;

public class SpriteAccessor implements TweenAccessor<Sprite>{
    
    public static final int  ALPHA = 1;
    public static final int SCALE = 2;
    public static final int POSITION = 3;
    
    
    @Override
    public int getValues(Sprite target, int tweenType, float[] returnValues) {
        switch(tweenType){
            case ALPHA:
                returnValues[0] = target.getColor().a;
                return 1;
            case SCALE:
                returnValues[0] = target.getScaleX();
                returnValues[1] = target.getScaleY();
                return 2;
            case POSITION:
                returnValues[0] = target.getX();
                returnValues[1] = target.getY();
            default:
                assert false;
                return -1;
        }
    }

    @Override
    public void setValues(Sprite target, int tweenType, float[] newValues) {
        switch(tweenType){
            case ALPHA:
                target.setAlpha(newValues[0]);
                break;
            case SCALE:
                target.setScale(newValues[0], newValues[1]);
                break;
            case POSITION:
                target.setPosition(target.getX()+newValues[0], target.getY()+newValues[1]);
                break;
            default:
                assert false;
        }
    }
    
}
