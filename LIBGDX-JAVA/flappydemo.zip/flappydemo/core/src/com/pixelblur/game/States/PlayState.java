
package com.pixelblur.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.TimeUtils;
import com.pixelblur.game.FlappyDemo;
import com.pixelblur.game.Sprites.Bird;
import com.pixelblur.game.Sprites.Tube;



public class PlayState extends State{
    private boolean flip_move = true;
    final private Bird bird;
    final private Texture background;
    final private Texture ground;
    final private Texture gameover;
    final private Vector2 groundPos1,groundPos2;
    final private static int TUBE_SPACING = 125;
    final private static int TUBE_COUNT = 4;
    final private static int GROUND_Y_OFFSET = -45;
    private long startingtime,startingtime1;
    final private Array<Tube> tubes;
    private int r;
    public PlayState(GameStateManager gsm) {
        super(gsm);
        bird = new Bird(50,300);
        background = new Texture("bg.png");
        ground = new Texture("ground.png");
        gameover =new Texture("gameover.png");
        groundPos1 = new Vector2(cam.position.x - cam.viewportWidth/2,GROUND_Y_OFFSET);
        groundPos2 = new Vector2((cam.position.x-cam.viewportWidth/2)+ground.getWidth(),GROUND_Y_OFFSET);
        cam.setToOrtho(false, FlappyDemo.WIDTH/2, FlappyDemo.HEIGHT/2);
        tubes = new Array<Tube>();
        for(int i=1;i<=TUBE_COUNT;i++){
            tubes.add(new Tube(i*(TUBE_SPACING+Tube.TUBE_WIDTH)));
        }
      
        startingtime = TimeUtils.millis();
        startingtime1 = TimeUtils.millis();
    }
   
    @Override
    protected void handleInput() {
        if(Gdx.input.justTouched()){
            
            bird.jump();
        }
        if(Gdx.input.justTouched() && bird.getCollision() == true){
                   
                    bird.setCollision(false);
                    gsm.set(new MenuState(gsm));
                    
                }
    }

    @Override
    public void update(float dt) {
        handleInput();
        bird.update(dt);
        updateGround();
        cam.position.x = bird.getPosition().x + 80;
        for(int i=0;i<tubes.size;i++){
            Tube tube = tubes.get(i);
            if(cam.position.x - cam.viewportWidth/2 > tube.getPosTopTube().x+tube.getTopTube().getWidth()){
                tube.reposition(tube.getPosTopTube().x + ((Tube.TUBE_WIDTH + TUBE_SPACING)*TUBE_COUNT));
            }
            if(tube.collides(bird.getBounds())){
               bird.setCollision(true);
            }
            if(TimeUtils.millis() >= startingtime1+3000){
                r = MathUtils.random.nextInt(5);
                startingtime1 = TimeUtils.millis();
            }
            if(r==5 || r==3 || r==2 || r==4){
                if(flip_move == false && bird.getCollision()== false){
                    if(TimeUtils.millis() >= startingtime+1000){
                        flip_move = true;
                        startingtime = TimeUtils.millis();
                    }
                    tube.getPosTopTube().y -= 0.5f;
                    tube.getPosBottomTube().y -= 0.5f;
                    tube.getTopBounds().y -= 0.5f;
                    tube.getBottomBounds().y -= 0.5f;
                }else if(flip_move == true && bird.getCollision() == false){
                    if(TimeUtils.millis() >= startingtime+1000){
                        flip_move = false;
                        startingtime = TimeUtils.millis();
                   
                    }
                    tube.getPosTopTube().y += 0.5f;
                    tube.getPosBottomTube().y += 0.5f;
                    tube.getTopBounds().y += 0.5f;
                    tube.getBottomBounds().y += 0.5;
                }
            }
        }
        cam.update();
    }

    @Override
    public void render(SpriteBatch sb) {
        
        sb.setProjectionMatrix(cam.combined);
        sb.begin();
        sb.draw(background,cam.position.x-(cam.viewportWidth/2),
                cam.position.y-(cam.viewportHeight/2));
        sb.draw(bird.getBird(),bird.getPosition().x,bird.getPosition().y);
        for(Tube tube:tubes){
           // sb.draw(tube.getBottomTube(), tube.getPosBottomTube().x, tube.getPosBottomTube().y);
           // sb.draw(tube.getTopTube(), tube.getPosTopTube().x, tube.getPosTopTube().y);
            tube.getBottomTube().setPosition(tube.getPosBottomTube().x, tube.getPosBottomTube().y);
            tube.getTopTube().setPosition(tube.getPosTopTube().x, tube.getPosTopTube().y);
            tube.getBottomTube().draw(sb);
            tube.getTopTube().draw(sb);
        }
        sb.draw(ground, groundPos1.x, groundPos1.y);
        sb.draw(ground, groundPos2.x, groundPos2.y);
        
        if(bird.getCollision() == true)
            sb.draw(gameover, cam.position.x - gameover.getWidth()/2, cam.position.y - gameover.getHeight()/2);
            //gameover.draw(sb);
        sb.end();
    }

    @Override
    public void dispose() {
        System.out.println("dispose called");
        ground.dispose();
        bird.dispose();
        for(Tube tube:tubes)
            tube.dispose();
        background.dispose();
        gameover.dispose();
    }
    private void updateGround(){
        if(cam.position.x - cam.viewportWidth/2 > groundPos1.x+ground.getWidth()){
            groundPos1.add(ground.getWidth()*2, 0);
        }
        if(cam.position.x - cam.viewportWidth/2 > groundPos2.x+ground.getWidth()){
            groundPos2.add(ground.getWidth()*2, 0);
        }
    }
}
