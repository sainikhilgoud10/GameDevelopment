
package com.pixelblur.game.States;

import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.equations.Elastic;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.pixelblur.game.FlappyDemo;



public class MenuState extends State{
    
    final private Texture background;
    final private Sprite playBtn;
    
    public MenuState(GameStateManager gsm) {
        super(gsm);
        background = new Texture("bg.png");
        playBtn = new Sprite(new Texture("playbtn.png"));
        cam.setToOrtho(false, FlappyDemo.WIDTH/2, FlappyDemo.HEIGHT/2);
        playBtn.setX(cam.position.x - playBtn.getWidth()/2);
        playBtn.setY(cam.position.y - playBtn.getHeight()/2);
        Tween.to(playBtn, SpriteAccessor.SCALE, 2f)
                .target(playBtn.getScaleX()+0.1f,playBtn.getScaleY()+0.1f)
                .ease(Elastic.INOUT)
                .repeatYoyo(-1, 0f)
                .start(tweenmanager);
        
    }

    @Override
    protected void handleInput() {
       if(Gdx.input.justTouched()){
            gsm.set(new PlayState(gsm));
        } 
    }

    @Override
    public void update(float dt) {
        tweenmanager.update(dt);
        handleInput();
    }

    @Override
    public void render(SpriteBatch sb) {
        sb.setProjectionMatrix(cam.combined);
        sb.begin();
        sb.draw(background,0,0);
        playBtn.draw(sb);
        sb.end();
    }
    
    @Override
    public void dispose(){
        System.out.println("dispose called");
        background.dispose();
        playBtn.getTexture().dispose();
        tweenmanager.killTarget(playBtn,SpriteAccessor.SCALE);
    }
}
