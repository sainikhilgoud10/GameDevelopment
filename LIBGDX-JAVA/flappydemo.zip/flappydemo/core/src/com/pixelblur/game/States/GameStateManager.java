package com.pixelblur.game.States;



import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.Stack;


public class GameStateManager {
    final private Stack<State> States;
    
    
    public GameStateManager(){
        States = new Stack<State>();
    }
    
    public void pop(){
        States.pop().dispose();
    }
    
    public void push(State state){
        States.push(state);
    }
    
    public void set(State state){
        States.pop().dispose();
        States.push(state);
    }
    
    public void update(float dt){
        States.peek().update(dt);
    }
    
    public void render(SpriteBatch sb){
        States.peek().render(sb);
    }
}
