
package com.pixelblur.game.Sprites;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import java.util.Random;

public class Tube {
    public static final int TUBE_WIDTH = 52;
    private static final int FLUCTUATION = 130;
    private static final int TUBE_GAP = 82;
    private static final int LOWEST_OPENING = 120;
    final private Sprite topTube,bottomTube;
    final private Vector2 posTopTube,posBottomTube;
    final private Random rand;
    final private Rectangle BoundsTop,BoundsBottom;
    public Tube(float x){
        topTube = new Sprite(new Texture("toptube.png"));
        bottomTube =new Sprite(new Texture("bottomtube.png"));
        rand = new Random();
        posTopTube = new Vector2(x,rand.nextInt(FLUCTUATION)+TUBE_GAP+LOWEST_OPENING);
        posBottomTube = new Vector2(x,posTopTube.y-TUBE_GAP - topTube.getHeight());
        
        BoundsTop = new Rectangle(posTopTube.x,posTopTube.y,topTube.getWidth(),topTube.getHeight());
        BoundsBottom = new Rectangle(posBottomTube.x,posBottomTube.y,bottomTube.getWidth(),bottomTube.getHeight());
    }

    Tube() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public Sprite getBottomTube(){
        return bottomTube;
    }
    public Sprite getTopTube(){
        return topTube;
    }
    public Vector2 getPosTopTube(){
        return posTopTube;
    }
    public Vector2 getPosBottomTube(){
        return posBottomTube;
    }
    public Rectangle getTopBounds(){
        return BoundsTop;
    }
    public Rectangle getBottomBounds(){
        return BoundsBottom;
    }
    
    public void reposition(float x){
        posTopTube.set(x,rand.nextInt(FLUCTUATION)+TUBE_GAP+LOWEST_OPENING );
        posBottomTube.set(x,posTopTube.y-TUBE_GAP - topTube.getHeight());
        BoundsTop.setPosition(posTopTube.x, posTopTube.y);
        BoundsBottom.setPosition(posBottomTube.x, posBottomTube.y);
    }
    
    public boolean collides(Rectangle player){
        return player.overlaps(BoundsTop) || player.overlaps(BoundsBottom);
    }
    
    public void dispose(){
        System.out.println("dispose called");
        topTube.getTexture().dispose();
        bottomTube.getTexture().dispose();
    }
    
}
