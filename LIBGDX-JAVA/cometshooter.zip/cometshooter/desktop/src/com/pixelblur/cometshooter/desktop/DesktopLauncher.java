package com.pixelblur.cometshooter.desktop;

import com.badlogic.gdx.Files;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.pixelblur.cometshooter.cometshooter;

public class DesktopLauncher {
	public static void main (String[] arg) {
		
                LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
                config.width = 480;
                config.height = 800;
                config.addIcon("sprites/unnamed.png", Files.FileType.Internal);
                config.resizable = false;
		new LwjglApplication(new cometshooter(), config);
	}
}
