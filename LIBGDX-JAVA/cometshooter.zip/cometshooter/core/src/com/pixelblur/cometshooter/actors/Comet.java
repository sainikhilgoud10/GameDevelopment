
package com.pixelblur.cometshooter.actors;

import com.badlogic.gdx.Gdx;

import com.badlogic.gdx.math.MathUtils;

public class Comet extends Actor{
  
    public Comet(int life, boolean dead, boolean isAlive, float px, float py, boolean collision) {
        super(life, dead, isAlive, px, py, collision);
        
    }

    @Override
    public void update(float delta) {
         this.POSITION_Y -= 5f;
         if(this.POSITION_Y<0){
             this.setiY(Gdx.graphics.getHeight());
             this.setiX(MathUtils.random(1, Gdx.graphics.getWidth()-43));
         }
    }
    
}
