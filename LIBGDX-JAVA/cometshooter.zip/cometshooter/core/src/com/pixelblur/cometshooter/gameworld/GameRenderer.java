
package com.pixelblur.cometshooter.gameworld;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector3;
import com.pixelblur.cometshooter.actors.Comet;
import com.pixelblur.cometshooter.actors.RocketPlayer;
import com.pixelblur.cometshooter.cameramanager.CameraView;
import com.pixelblur.cometshooter.helperclasses.AssetLoader;




public class GameRenderer {
    final private GameWorld myworld;
    private RocketPlayer rocket;
    private Comet comet;
    private Sprite rocket_image;
    private Sprite comet_image;
    final private SpriteBatch batch;
    final private ShapeRenderer gradient;
    final private CameraView cv;
    final private OrthographicCamera gamerendercamera;
    
    
    public GameRenderer(GameWorld world,CameraView cam){
        myworld = world;
        gradient = new ShapeRenderer();
        batch = new SpriteBatch();
        cv = cam;
        gamerendercamera = cv.getCamera();
        initGameObjects();
        initAssets();
    }
    public void render(float delta){
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        gamerendercamera.update();
        gradient.begin(ShapeRenderer.ShapeType.Filled);
        gradient.rect(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), Color.valueOf("ecf0f1"), Color.valueOf("bdc3c7"), Color.valueOf("95a5a6"), Color.valueOf("7f8c8d"));
        gradient.end();
        batch.setProjectionMatrix(gamerendercamera.combined);
        batch.begin();
        batch.draw(rocket_image,rocket.getiX()-rocket_image.getWidth()/2,rocket.getiY());
        batch.draw(comet_image,comet.getiX(),comet.getiY());
        batch.end();
    }

    private void initAssets() {
        rocket_image = AssetLoader.sprite;
        comet_image = AssetLoader.commet_images.get(MathUtils.random.nextInt(5));
    }

    private void initGameObjects() {
        rocket = myworld.getRocket();
        comet = myworld.getComet();
    }
    public ShapeRenderer getGradient(){
        return gradient;
    }
    public void updateCameraProjection(Vector3 touchpos){
        gamerendercamera.unproject(touchpos);
    }
    
}
