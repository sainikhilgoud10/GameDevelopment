
package com.pixelblur.cometshooter.gameworld;



import com.pixelblur.cometshooter.actors.Comet;
import com.pixelblur.cometshooter.actors.RocketPlayer;
import com.pixelblur.cometshooter.cameramanager.CameraView;


public class GameWorld {
    final private RocketPlayer myrocket;
    final private Comet comet;
    final private CameraView cv;
    public GameWorld(CameraView cam){
        cv = cam;
        myrocket = new RocketPlayer(3,false,true,cv.GameWorldWidth/2-64,1,false);
        comet = new Comet(1,false,true,cv.GameWorldWidth/2,cv.GameWorldHeight,false);
    }
    public void update(float delta){
        myrocket.update(delta);
        comet.update(delta);
    }
    public RocketPlayer getRocket(){
        return myrocket;
    }
    public Comet getComet(){
        return comet;
    }
}
