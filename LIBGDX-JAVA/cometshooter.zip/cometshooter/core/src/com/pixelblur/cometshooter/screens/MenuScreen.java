
package com.pixelblur.cometshooter.screens;

import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenManager;
import aurelienribon.tweenengine.equations.Bounce;
import aurelienribon.tweenengine.equations.Quad;
import aurelienribon.tweenengine.equations.Quint;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector3;
import com.pixelblur.cometshooter.cameramanager.CameraView;
import com.pixelblur.cometshooter.helperclasses.AssetLoader;
import com.pixelblur.cometshooter.tweenmanager.SpriteAccessor;



public class MenuScreen implements Screen{

    final private Game mygame;
    private ShapeRenderer gradient;
    private Sprite play_button;
    private SpriteBatch batch;
    final private CameraView cv;
    private OrthographicCamera camera;
    private TweenManager tweenmanager;
    
    
    public MenuScreen(Game game,CameraView cam){
        mygame = game;
        cv = cam;
    }
    
    @Override
    public void show() {
        
        camera = cv.getCamera();
        batch = new SpriteBatch();
        gradient = new ShapeRenderer();
        tweenmanager = new TweenManager();
       
        play_button = new Sprite(AssetLoader.play_image);
        play_button.setX(cv.GameWorldWidth+200);
        play_button.setY(cv.GameWorldHeight/2-play_button.getHeight()/2);
         Tween.registerAccessor(Sprite.class, new SpriteAccessor());
        Tween.to(play_button, SpriteAccessor.POSITION, 2f).target(cv.GameWorldWidth/2-play_button.getWidth()/2,cv.GameWorldHeight/2-play_button.getHeight()/2
        ).ease(Quint.INOUT).start(tweenmanager);
        
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(1, 1, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        tweenmanager.update(delta);
        camera.update();
        gradient.begin(ShapeRenderer.ShapeType.Filled);
        gradient.rect(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), Color.valueOf("ecf0f1"), Color.valueOf("bdc3c7"), Color.valueOf("95a5a6"), Color.valueOf("7f8c8d"));
        gradient.end();
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        play_button.draw(batch);
        batch.end();
        
        if(Gdx.input.justTouched()){
           Vector3 TouchPos  = new Vector3();
           TouchPos.x = Gdx.input.getX();
           TouchPos.y = Gdx.input.getY();
           if(play_button.getBoundingRectangle().contains(TouchPos.x, TouchPos.y)){
                mygame.setScreen(new GameScreen(mygame,cv));
           }
        }
    }

    @Override
    public void resize(int width, int height) {
    
    }

    @Override
    public void pause() {
     
    }

    @Override
    public void resume() {
    
    }

    @Override
    public void hide() {
        dispose();
    }

    @Override
    public void dispose() {
        gradient.dispose();
        play_button.getTexture().dispose();
    }

   
    
}
