
package com.pixelblur.cometshooter.helperclasses;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.utils.Array;


public class AssetLoader {
    public static TextureAtlas textureatlas;
    public static Texture rocket_image,explosion_image,missile_image;
    public static Texture  play_image,pause_image,splash_image;
    public static Texture  commet_image;
    public static Array<Sprite> commet_images;
    public static Sprite sprite;
    public static void load(){
        commet_images = new Array<Sprite>();
        for(int i=1;i<=5;i++){
            commet_images.add(new Sprite(new Texture(Gdx.files.internal("sprites/comet_"+i+".png"))));
        }
        splash_image    = new Texture(Gdx.files.internal("sprites/splashscreen.png"));
        play_image      = new Texture(Gdx.files.internal("sprites/playbutton.png"));
        pause_image     = new Texture(Gdx.files.internal("sprites/pausebutton.png"));
        rocket_image    = new Texture(Gdx.files.internal("sprites/rocket.png"));
        sprite = new Sprite(rocket_image);
        explosion_image = new Texture(Gdx.files.internal("sprites/explosion.png"));
        missile_image   = new Texture(Gdx.files.internal("sprites/missile.png"));
        commet_image    = new Texture(Gdx.files.internal("sprites/comet_2.png"));
             
    }
    public static void dispose(){

        splash_image.dispose();
        play_image.dispose();
        pause_image.dispose();
        rocket_image.dispose();
        explosion_image.dispose();
        missile_image.dispose();
        commet_image.dispose();
    
    }
}
