
package com.pixelblur.cometshooter.actors;

import com.pixelblur.cometshooter.cameramanager.CameraView;


public class RocketPlayer extends Actor {
    CameraView cv;
    
    public RocketPlayer(int life, boolean dead, boolean isAlive, float px, float py, boolean collision) {
        super(life, dead, isAlive, px, py, collision);
    }
    @Override
    public void update(float delta){
            
     
    }
    public void onClick(float x,float y){
            this.setiX(x);
    }
}
