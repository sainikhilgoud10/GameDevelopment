
package com.pixelblur.cometshooter.actors;


public abstract class Actor {
    
    protected int LIFE;
    protected boolean DEAD;
    protected boolean ALIVE;
    protected float POSITION_X;
    protected float POSITION_Y;
    protected boolean COLLIDE;
    
    public Actor(int life,boolean dead,boolean isAlive,float px,float py,boolean collision){
        LIFE = life;
        DEAD = dead;
        ALIVE = isAlive;
        POSITION_X = px;
        POSITION_Y = py;
        COLLIDE = collision;
    }
    public abstract void update(float delta);
    public int getLife(){
        return LIFE;
    }
    public boolean isDead(){
        return DEAD;
    }
    public boolean isAlive(){
        return ALIVE;
    }
    public float getiX(){
        return POSITION_X;
    }
    public float getiY(){
        return POSITION_Y;
    }
    public boolean isCollide(){
        return COLLIDE;
    }
    
    
    public void setLife(int life){
        this.LIFE = life;
    }
    public void setiX(float x){
        this.POSITION_X = x;
    }
    public void setiY(float y){
        this.POSITION_Y = y;
    }
    public void setAlive(boolean isalive){
        this.ALIVE = isalive;
    }
    public void setDead(boolean isdead){
        this.DEAD = isdead;
    }
    public void setCollision(boolean iscollide){
        this.COLLIDE = iscollide;
    }
}
