
package com.pixelblur.cometshooter.screens;

import aurelienribon.tweenengine.Tween;
import aurelienribon.tweenengine.TweenManager;
import aurelienribon.tweenengine.equations.Bounce;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.utils.TimeUtils;
import com.pixelblur.cometshooter.cameramanager.CameraView;
import com.pixelblur.cometshooter.helperclasses.AssetLoader;
import com.pixelblur.cometshooter.tweenmanager.SpriteAccessor;


public class SplashScreen implements Screen {

    private Sprite splashscreen;
    private SpriteBatch batch;
    final private Game mygame;
    private long splash_start_time;
    private TweenManager tweenmanager;
    private ShapeRenderer gradient;
    private OrthographicCamera camera;
    final private CameraView cv;
    public SplashScreen(Game game,CameraView cam){
        mygame = game;
        cv = cam;
    }
    
    @Override
    public void show() {

        camera = cv.getCamera();
        splashscreen = new Sprite(AssetLoader.splash_image);
        splashscreen.setPosition(cv.GameWorldWidth/2-splashscreen.getWidth()/2,cv.GameWorldHeight/2-splashscreen.getHeight()/2);
        batch = new SpriteBatch();
        gradient = new ShapeRenderer();
        tweenmanager = new TweenManager();
        Tween.registerAccessor(Sprite.class, new SpriteAccessor());
        splash_start_time = TimeUtils.millis();
        Tween.to(splashscreen, SpriteAccessor.ALPHA, 3).delay(3).target(0).start(tweenmanager);
        Tween.to(splashscreen, SpriteAccessor.POSITION, 1.5f).target(cv.GameWorldWidth/2-splashscreen.getWidth()/2,cv.GameWorldHeight-splashscreen.getHeight()).ease(Bounce.OUT).start(tweenmanager);
        
    }
    
    @Override
    public void render(float delta) {
        
        Gdx.gl.glClearColor(0.41f, 0.128f, 0.185f, 1.0f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        camera.update();
        tweenmanager.update(delta);
        
        gradient.begin(ShapeRenderer.ShapeType.Filled);
        gradient.rect(0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), Color.valueOf("ecf0f1"), Color.valueOf("bdc3c7"), Color.valueOf("95a5a6"), Color.valueOf("7f8c8d"));
        gradient.end();
        batch.setProjectionMatrix(camera.combined);
        batch.begin();
        splashscreen.draw(batch);
        batch.end();
         
        
        if(TimeUtils.millis()>(splash_start_time+6000)){
            removeSplash();
        }
    }
    
    private void removeSplash(){
        
        //tweenmanager.killAll();
        mygame.setScreen(new MenuScreen(mygame,cv));
    
    }
    
    @Override
    public void resize(int width, int height) {
        
        
    }

    @Override
    public void pause() {
       
    }

    @Override
    public void resume() {
        
    }

    @Override
    public void hide() {
        dispose();
    }

    @Override
    public void dispose() {
      
        splashscreen.getTexture().dispose();
        batch.dispose();
        gradient.dispose();
        tweenmanager.killAll();
        
    }
    
}
