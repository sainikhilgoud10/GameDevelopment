
package com.pixelblur.cometshooter.screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.pixelblur.cometshooter.cameramanager.CameraView;
import com.pixelblur.cometshooter.gameworld.GameRenderer;
import com.pixelblur.cometshooter.gameworld.GameWorld;
import com.pixelblur.cometshooter.helperclasses.InputHandler;


public class GameScreen implements Screen{
    private GameRenderer render;
    private GameWorld world;
    final private Game mygame;
    private float runtime;
    final private CameraView cv;

    
    public GameScreen(Game game,CameraView cam){
        mygame = game;
        cv = cam;
    }
    @Override
    public void show() {
        world = new GameWorld(cv);
        render = new GameRenderer(world,cv);
        Gdx.input.setInputProcessor(new InputHandler(world.getRocket()));
    }

    
    @Override
    public void render(float delta) {
        
        runtime+=delta;
        world.update(delta);
        render.render(runtime);
    }

    @Override
    public void resize(int width, int height) {
       
    }

    @Override
    public void pause() {
    
    }

    @Override
    public void resume() {
    
    }

    @Override
    public void hide() {
        dispose();
    }

    @Override
    public void dispose() {
        System.out.println("dispose called in gamescreen");
        render.getGradient().dispose();
    }
    

}
