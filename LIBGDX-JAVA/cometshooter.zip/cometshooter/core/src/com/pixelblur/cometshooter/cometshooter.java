package com.pixelblur.cometshooter;


import com.badlogic.gdx.Game;
import com.pixelblur.cometshooter.cameramanager.CameraView;
import com.pixelblur.cometshooter.helperclasses.AssetLoader;
import com.pixelblur.cometshooter.screens.SplashScreen;


public class cometshooter extends Game {
	private CameraView cam;
	
	@Override
	public void create () {
            AssetLoader.load();
             cam = new CameraView();
            setScreen(new SplashScreen(this,cam));
            
        }
        @Override
        public void render(){
            super.render();
        }
	@Override
        public void dispose(){
            super.dispose();
            AssetLoader.dispose();
        }
        @Override
        public void resize(int width,int height){
            cam.viewUpdate(width, height);
        }
}
