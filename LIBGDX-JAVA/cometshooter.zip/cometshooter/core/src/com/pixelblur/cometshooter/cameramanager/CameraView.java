
package com.pixelblur.cometshooter.cameramanager;


import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.badlogic.gdx.utils.viewport.FillViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.utils.viewport.FitViewport;

import com.badlogic.gdx.utils.viewport.Viewport;

public class CameraView {
    public float GameWorldWidth,GameWorldHeight;
    private static OrthographicCamera camera;
    private static Viewport viewport;
    public CameraView(){
        GameWorldWidth = Gdx.graphics.getWidth();
        GameWorldHeight = Gdx.graphics.getHeight();
        camera = new OrthographicCamera();
       // camera.setToOrtho(false, 480, 800);
        float aspectratio = (float)GameWorldHeight/GameWorldWidth;
        viewport = new FillViewport(GameWorldWidth*aspectratio,GameWorldHeight,camera);
        camera.position.set(GameWorldWidth/2, GameWorldHeight/2, 0);
    }
    public void viewUpdate(int NewWidth,int NewHeight){
        viewport.update(NewWidth,NewHeight);
        camera.position.set(GameWorldWidth/2, GameWorldHeight/2, 0);
    }
    public OrthographicCamera getCamera(){
        return camera;
    }
}
